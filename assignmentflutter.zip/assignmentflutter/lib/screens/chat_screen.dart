import 'package:assignmentflutter/constants/colorcode.dart';
import 'package:assignmentflutter/main.dart';
import 'package:flutter/material.dart';
class ChatScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: Stack(
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: ColorCode.flutterColor5, // Adjust the background color as needed
                      ),
                      child: IconButton(
                        icon: Icon(Icons.arrow_back),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle, size: 24), // Placeholder for the Cooper logo
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Text(
                            "Cooper 1.7",
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                children: [
                  Center(
                    child: Text(
                      "Today",
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 16.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Spacer(),
                        Flexible(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                padding: EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: ColorCode.flutterColor4,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  "Provide statistics on the development of the Indonesian population",
                                  style: TextStyle(fontSize: 16),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 4.0),
                                child: Text("1 min ago", style: TextStyle(color: Colors.grey)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 16.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CircleAvatar(
                          backgroundColor: Colors.black,
                          child: Icon(Icons.circle, color: Colors.white), // Placeholder for the Cooper logo
                        ),
                        SizedBox(width: 8), // Add some spacing between avatar and message
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // First Card - Text Message
                              Container(
                                padding: EdgeInsets.all(8), // Reduce padding for the outer container
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  "Well, here's the latest statistical data on Indonesia's population",
                                  style: TextStyle(fontSize: 16),
                                ),
                              ),
                              SizedBox(height: 8), // Add some vertical spacing between cards
                              // Second Card - Statistics
                              Container(
                                padding: EdgeInsets.all(35), // Add padding around the Column
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 2,
                                      blurRadius: 5,
                                      offset: Offset(0, 3),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "2022",
                                      style: TextStyle(color: Colors.grey, fontSize: 14),
                                    ),
                                    SizedBox(height: 8), // Add some vertical spacing between year and population
                                    Text(
                                      "275.5 million",
                                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(height: 16), // Add some vertical spacing between population and bars
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                                      children: [
                                        Container(
                                          width: 24, // Adjust width of bars
                                          height: 60, // Adjust height of bars
                                          decoration: BoxDecoration(
                                            color: ColorCode.flutterColor,
                                            borderRadius: BorderRadius.circular(8), // Add border radius to the container
                                          ),
                                        ),
                                        Container(
                                          width: 24, // Adjust width of bars
                                          height: 60, // Adjust height of bars
                                          decoration: BoxDecoration(
                                            color: ColorCode.flutterColor1,
                                            borderRadius: BorderRadius.circular(8), // Add border radius to the container
                                          ),
                                        ),
                                        Container(
                                          width: 24, // Adjust width of bars
                                          height: 60, // Adjust height of bars
                                          decoration: BoxDecoration(
                                            color: ColorCode.flutterColor,
                                            borderRadius: BorderRadius.circular(8), // Add border radius to the container
                                          ),
                                        ),
                                        Container(
                                          width: 24, // Adjust width of bars
                                          height: 60, // Adjust height of bars
                                          decoration: BoxDecoration(
                                            color: ColorCode.flutterColor1,
                                            borderRadius: BorderRadius.circular(8), // Add border radius to the container
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 8), // Add some vertical spacing
                              Text("Just now", style: TextStyle(color: Colors.grey)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                        hintText: "Ask anything here..",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25),
                        ),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: PopupMenuButton<String>(
                      itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                        CustomPopupMenuItem(
                          icon: Icons.mic,
                          color: Colors.black, // Grey background color
                          onTap: () {
                            // Handle audio selection
                          },
                        ),
                        CustomPopupMenuItem(
                          icon: Icons.image,
                          color: Colors.black, // Grey background color
                          onTap: () {
                            // Handle image selection
                          },
                        ),
                        CustomPopupMenuItem(
                          icon: Icons.video_call,
                          color: Colors.black, // Grey background color
                          onTap: () {
                            // Handle video selection
                          },
                        ),
                      ],
                      child: Container(
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: ColorCode.flutterColor2,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(Icons.add, color: ColorCode.flutterColor3),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

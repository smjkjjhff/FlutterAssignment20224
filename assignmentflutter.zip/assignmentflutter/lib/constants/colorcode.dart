import 'package:flutter/material.dart';

class ColorCode {
  static const Color flutterColor = Color.fromRGBO(254, 236, 186, 1.0);
  static const Color flutterColor1 = Color.fromRGBO(214, 208, 253, 1.0);
  static const Color flutterColor2 = Color.fromRGBO(211, 206, 249, 1.0);
  static const Color flutterColor3 = Color.fromRGBO(54, 53, 59, 1.0);
  static const Color flutterColor4 = Color.fromRGBO(210, 204, 240, 1.0);
  static const Color flutterColor5 = Color.fromRGBO(248, 248, 252, 1.0);
  static const Color flutterColor6 = Color.fromRGBO(254, 236, 186, 1.0);
  static const Color flutterColor7 = Color.fromRGBO(213, 207, 252, 1.0);
  static const Color color1 = Color.fromRGBO(42, 1, 130, 1.0);
  static const Color color2 = Color.fromRGBO(111, 48, 245, 1.0);
  static const Color flutterColor8 = Color.fromRGBO(171, 164, 194, 1.0);
  static const Color color3 = Color(0xFFF8F8FC);
  static const Color color4 = Color(0xFF3A3B3F);

  static const Color color8 = Color(0xFFFEECBA);

  static const Color color5 = Color(0xFFF9A79F);



}
